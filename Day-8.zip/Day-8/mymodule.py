students ={1:'Rutvik',2:'Keshav',3:'Mayur',4:'Radhika'}


def iseven(n):
    return n%2== 0


def isodd(n):
    return n%2== 1


def ispositive(n):
    return n>0



def isnegative(n):
    return n<0