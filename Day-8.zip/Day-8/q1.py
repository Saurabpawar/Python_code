import calculator as cl
a=int(input("Enter number"))
b=int(input("Enter number"))

print(cl.add(a,b))
print(cl.subtract(b,a))
print(cl.multiply(a,b))
print(cl.square(a,b))
print(cl.ispos(a))
