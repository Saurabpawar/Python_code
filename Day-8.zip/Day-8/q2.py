import mylist as ls
'''
print(ls.disp())

print(ls.revd())

print(ls.dalter())

ls.upp()

ls.low()

ls.dup()
'''

ls.uni()
