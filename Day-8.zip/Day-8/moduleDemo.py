#1

import mymodule

print(mymodule.students[1])

print(mymodule.iseven(23))
print(mymodule.isodd(23))

print(mymodule.ispositive(23))
print(mymodule.isnegative(23))