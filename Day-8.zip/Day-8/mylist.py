lst=["asas","asa","vxc",2,2,3,1]
lst2=[1,2,3,4,5,6]
'''
def disp():
    return lst

def revd():
        lst1=[]
        lst1=lst
        lst1.reverse()
        return lst1,lst

def dalter():
    return lst[::2]


    
def upp():
    lst1 = [x.upper() for x in lst]
    print(lst1)
def low():
    lst2=[x.lower() for x in lst]
    print(lst2)
'''

def upp():
    lst1 = [x.upper() if isinstance(x, str) else x for x in lst]
    print(lst1)

def dup():
    for i in lst:
        if lst.count(i)>=2:
            print(i)
            
def uni():
    print(list(set(lst)))
