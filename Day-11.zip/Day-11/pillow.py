# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 17:21:00 2023

@author: Admin
"""

import PIL 
#print(PIL.__version__)

from PIL import Image,ImageFilter
img = Image.open(r"F:\CDAC DBDA\Python\Day12\Images\ele.jpg")
#img.show() #open in external s/w
display(img)