a="Hello world"
n=int(input("Enter number"))
print(a[0:n] + a[n+1:15])

