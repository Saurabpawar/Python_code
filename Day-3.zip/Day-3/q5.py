a=input("Enter String")
count=0
for i in a:
    count+=1
print(count)
