a=input("Enter String")
print(a[:2]+a[len(a)-2:])
