s="Hello world"
x=s.replace("e","$")
print(x)
