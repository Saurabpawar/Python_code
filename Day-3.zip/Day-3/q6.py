a=input("Enter String")
len=(len(a))
print(a[2:len:2])
    
