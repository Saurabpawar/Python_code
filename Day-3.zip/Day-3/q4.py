a=input("Enter String")
x=a.replace(" ","-")
print(x)
