a=int(input("Enter number"))
r=0
while a>0:
    r+=a%10
    a=a//10
print(r)
    
    
    
