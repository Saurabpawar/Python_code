a=int(input("Enter number"))

for i in range(1,a+1):
    print(a,"X",i,"=",a*i)
