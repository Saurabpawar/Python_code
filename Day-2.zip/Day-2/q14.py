a=7
for i in range(1,7):
    
        print(i*7)
