for j in range(1,10):
    for i in range(2,11):
        print(j*i,end="\t")
    print("")
        
