a=int(input("Enter number"))
sum=0
for i in range(1,a+1):
    sum=i+sum
print(sum)
