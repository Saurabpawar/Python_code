a=input("Enter word ::")
s=""
for i in a:
    s=i+s
print(s)
