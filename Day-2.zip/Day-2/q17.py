for i in range(-10,0):
    print(i)
if i>10:
       print("Done")
else:
        print("Done")
