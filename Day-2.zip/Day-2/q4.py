a=input("Enter a number")
s=''
for i in a:
    s=i+s
    
if s==a:
    print("Palindrome")
else :
    print("Not palindrome")



