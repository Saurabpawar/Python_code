a=int(input("Enter number"))
f=1
for i in range(1,a+1):
    f=i*f
print(f)
