start=int(input("Start from :: "))
stop=int(input("Stop at :: "))

for i in range(start,stop+1):
    if i%2!=0:
        print(i)
