a=int(input("enter number"))
count=0
while a>0:
    count=count+1
    a=a//10
print(count)
