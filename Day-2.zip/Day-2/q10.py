x=input("Enter number")

for i in x:
    print(i, end="\n")
    if i=='a':
        print("A for Apple")
    elif i=='b':
        print("B for Ball")
    else :
        print("")
