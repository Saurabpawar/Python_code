'''
a=int(input("Enter num"))
for i in range(1,a):
    for j in range(1,i+1):
        print("*",end="")
    print("")
print("_________________________________")

a=int(input("Enter num"))
for i in range(1,a):
    for j in range(1,i+1):
        print(j,end="")
    print("")

print("_____________________________________")

a=int(input("Enter num"))
for i in range(1,a):
    for j in range(1,i+1):
        print(i,end="")
    print("")

print("____________________________________")
'''
a=int(input("Enter num"))
for i in range(1,a):
    for j in range(1,a+1):
        for k in range(a-1,0,-1):
            print('*',end="")
    print("")
