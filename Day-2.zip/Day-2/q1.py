a=input("Enter a number")
s=' '
for i in a:
    s=i+s
print(s)

print("______________________________________________")

x=int(input("Enter a number"))
r=0
while x>0:
    r=x%10
    x=x//10
    print(r, end="")
