def eve(a,b):
    even=[x for x in range(a,b) if x%2==0]
    return even

print(eve(4,30))
