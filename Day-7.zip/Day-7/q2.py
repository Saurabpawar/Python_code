def func(a,*b):
    print(a)
    for i in b:
        print(i)
    return

func(10)
func(20,30,40)
