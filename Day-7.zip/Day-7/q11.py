l1= lambda a:a+15
l2= lambda x,y:x*y
a=int(input("Enter number"))
print(l1(5),l2(a,2))
