def square(a):
    print(a**2)

sq=square
a=int(input("Entetr number :: "))
sq(a)
