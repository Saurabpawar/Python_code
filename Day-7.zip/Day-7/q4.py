def showEmp(name,sal=5555):
    print(name,sal)

a=input("Enter name")
b=input("Enter salar")

showEmp(a)
showEmp(a,b)



