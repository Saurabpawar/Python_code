def calculation(a,b):
    ad=a+b
    sb=a-b
    return ad,sb

print(calculation(20,10))
            
