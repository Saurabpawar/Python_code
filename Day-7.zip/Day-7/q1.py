def getname(name,age):
    print(name,age)

getname("SAURAB",20)
