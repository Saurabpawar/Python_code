lst1=[1,2,3,4,5,6]
lst=[]
no=int(input("Ente no of elements in lst"))
for i in range(no):
    a=int(input("Enter element"))
    lst.append(a)
    print(lst)

def square(n):
    return n*n



res=list(map(square,lst))
res1=dict(zip(lst,res))
print(res1)
print(res)
