l1=['r','g','b']
l2=['red','green','blue']
def di():
    d=dict(**l1,**l2)
    return d
print(di())
