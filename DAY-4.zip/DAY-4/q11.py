lst=[1,2,3,3,4,5,6]
duplicate=list(set(lst))
print(duplicate)
