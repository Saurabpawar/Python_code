lst=[6,2,3,4,5,1]
ind=0
ind=lst[-1]
temp=lst[0]
lst[0]=ind
lst[-1]=temp
print(lst)
