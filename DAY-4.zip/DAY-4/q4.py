lst=["Monday","Tuesday","Wednesday"]
for i in lst:
    print(i[:3])
