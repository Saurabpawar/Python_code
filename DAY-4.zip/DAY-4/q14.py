lst=()
lst1=[(x,x**2) for x in range(11,20)]
lst=lst1
print(lst)
