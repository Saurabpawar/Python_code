lst=[1,2,3,4,5,5,6,6,6,7,8,8,9]
cnt=0
a=int(input("Enter number to Search"))
for i in lst:
    if i==a:
        cnt+=1
print(a,"Number presnet ",cnt,"times")
