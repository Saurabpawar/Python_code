lst=[-3,-2,-1,1,2,3,4,5,6]
n=0
b=0
c=0
for i in lst:
    if i<0:
        n=n+i
    elif i>0:
        if i%2==0:
            b=b+i
        else :
            c=c+1
print(n,b,c)
