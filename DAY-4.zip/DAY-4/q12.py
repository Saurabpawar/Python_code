lst=[1,2,3,4,5]
no=int(input("Enter number"))
res=lst.index(no)
print(res)

