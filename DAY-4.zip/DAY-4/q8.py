lst=[1,2,3,4,5,6,7]
lod=[]
lev=[]
for i in lst:
    if i%2==0:
        lev.append(i)
    elif i%2!=0:
        lod.append(i)
print(lod)
print(lev)
