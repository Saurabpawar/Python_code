lst=[1,2,3,4,6,6,7,5]
leve=[]
lodd=[]
for i in lst:
    if i%2!=0:
        
        lodd.append(i)

    elif i%2==0:
        
        leve.append(i)
print(leve)
print(lodd)
print(max(leve))
print(max(lodd))           
            
