lst=[1,2,3,4,5]
s=0
for i in lst:
    s=s+i
print(s//len(lst))


su=sum(lst)
ans=su/len(lst)
print(ans)
