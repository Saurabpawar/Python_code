lst=[1,2,3,4,5]
lsa=[6,7,8,9,10]
for i in lsa:
    lst.append(i)
print(lst)

l3=[]
l3=lst+lsa
print(l3)
    

