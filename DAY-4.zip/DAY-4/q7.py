lst=[1,2,4,6,8,2]
lst.sort()
print(lst[-2:-1])

