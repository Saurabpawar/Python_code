a=int(input("enter unit"))
num1=1
if a<=100:
    sum=10
elif a>100 and a<200:
    sum=(200-a)*5
elif a>200:
    sum=500+(a-200)*10
print(sum)
