a=int(input("Enter principal amount"))
b=int(input("Enter time"))
c=int(input("Enter rate"))

res=(a+b+c)/100

print("simple interest :: ",res)
