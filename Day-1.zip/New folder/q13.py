cp=int(input("Enter Bike price"))
if cp>100000:
    sum=cp+(cp*0.15)
    print(sum)
elif cp>50000 <=100000:
    sum=cp+(cp*0.10)
    print(sum)
elif cp<=50000:
    sum=cp+(cp*0.05)
    print(sum)
