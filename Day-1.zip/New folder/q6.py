a=int(input("Enter temperature"))
res=(a*1.8+32)
print("Celcius :: ",res)
