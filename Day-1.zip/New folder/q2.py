a=int(input("Enter number"))

if a>=0:
    print("Positive Number")
else:
    print("Negative number")
