a=int(input("Enter side"))
b=int(input("Enter side"))
c=int(input("Enter side"))

if a==b and a==c:
    print("equilateral")
elif a!=b and a!=c:
    print("Scalene")
else :
    print("isoceles")
