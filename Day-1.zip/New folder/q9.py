age=int(input("Enter age"))
if age>=18:
    print("Eligible for voting")
else :
    print("Not eligible")
