a=(input("Enter number"))
res = int(a)+int(a+a)+int(a+a+a)
print(res)

