year=int(input("Enter number"))
if year%400==0 and year%100!=0 or year%4==0:
    print("leap year")
else :
    print("Not leap year")
