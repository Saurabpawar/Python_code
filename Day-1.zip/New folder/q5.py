a=int(input("Enter number"))
b=int(input("Enter number"))
c=int(input("Enter number"))
if a>b and a>c:
    print("A is greate")
elif b>a and b>c :
    print("B is greater")
else :
    print("C is greater")
