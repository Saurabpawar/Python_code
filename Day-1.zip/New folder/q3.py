hindi=int(input("Enter number"))
english=int(input("Enter number"))
maths=int(input("Enter number"))
evs=int(input("Enter number"))
sst=int(input("Enter number"))

percent=((hindi+english+maths+evs+sst)/500)*100

if percent>90:
    print("Grade A")
elif percent>=75 and percent<90:
    print("Grade B")
else :
    print("Grade C")
