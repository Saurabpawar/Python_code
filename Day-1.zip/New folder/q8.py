a=int(input("Enter height in centimeters"))

inch=a/2.54
feet = int(inch // 12)
r_inch = inch % 12
print("height in inch ::",feet)
print("height in feet ::",r_inch)

fe=a//30
rem=a%30.48
inch=rem/2.54
print(feet,"and",inch)
