a=2
b=3
c=4
a,b,c=c,b,a
print(a,b,c)

