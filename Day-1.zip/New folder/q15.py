a=int(input("enter number"))
if a==1:
    print("MONDAY")
elif a==2:
    print("tuesday")

elif a==3:
    print("wednesday")
elif a==4:
    print("thursday")
elif a==5:
    print("friday")
