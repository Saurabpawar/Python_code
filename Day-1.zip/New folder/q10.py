
a=int(input("Enter number"))
c=a%7
if c==0:
    print("Divisible by 7")
else :
    print("Not divisible")
