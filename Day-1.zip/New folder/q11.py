a=int(input("Enter number"))

if a%5 == 0:
    print("IT is multiple of five")
else :
    print("not multiple")
