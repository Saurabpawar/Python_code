class rstr:
    def __init__(self,str1):
        self.str1=str1

    def revv(self):
        s=self.str1.split()
        x=s[::-1]
        return x

o=rstr("I love my India")
print(o.revv())
