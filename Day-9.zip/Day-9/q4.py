class ass:
    def get_string(self,name):
        self.n=name
    def printstring(self):
        print(self.n.upper())

e=ass()
e.get_string("asas")
e.printstring()
