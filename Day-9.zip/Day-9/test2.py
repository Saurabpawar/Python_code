print(dir(Str))
