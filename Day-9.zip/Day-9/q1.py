class power:
    def __init__(self,no,re):
        self.no=no
        self.re=re

    def cal(self):
        return self.no**self.re

     
    def __del__(self,no,re):
        print("Destructor")
 

e=power(4,2)
print(e.cal())
