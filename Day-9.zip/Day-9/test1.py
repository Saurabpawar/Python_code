lst=[5,7,9]
lst1={}
for i in lst:
    lst1.update({i:[i*j for j in range(1,11)]})
       
print(lst1)


