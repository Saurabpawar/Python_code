class temp:
    def cel(self,t):
        c=(t-32)*(5/9)
        return c
    def fer(self,t):
        f=(t*(9/5))+32
        return f

e=temp()
print(e.cel(89.6))
print(e.fer(32))
        
