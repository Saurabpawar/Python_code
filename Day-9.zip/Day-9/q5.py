class rec:
    leng=0
    bre=0
    def __init__(self,l,b):
        self.leng=l
        self.bre=b

    def area(self):
        return self.leng*self.bre


e=rec(4,6)
print(e.area())
