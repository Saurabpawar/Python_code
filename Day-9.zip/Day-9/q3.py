'''
def __init__(self,n1,n2):
    self.n1=n1
    self.n2=n2
'''
def calculation(n1,n2):
    return n1+n2


print(calculation(10,20))
