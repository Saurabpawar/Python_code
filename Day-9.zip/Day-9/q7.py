class stud:
    roll=22
    name="Saurab"

    def set_age(self,age):
        self.age=age
    def set_mark(self,mark):
        self.mark=mark
    def get_det(self):
        #print(self.name,self.roll,self.age,self.mark)
        return(f"name is {self.name} roll = {self.roll} age = {self.age} marks={self.mark}")
        
e=stud()
e.set_age(20)
e.set_mark(98)
print(e.get_det())
